<?php 
sleep(3);
header ("Content-Type: text/css");  
echo ".class5{color:pink}";