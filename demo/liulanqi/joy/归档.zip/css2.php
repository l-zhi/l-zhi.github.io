<?php 
sleep(3);
header ("Content-Type: text/css");  
echo ".class2{color:gray}";