<?php 
sleep(5);
header ("Content-Type: text/css");
echo ".class6{color:blue}";