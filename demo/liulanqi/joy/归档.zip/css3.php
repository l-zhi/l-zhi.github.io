<?php 
sleep(5);
header ("Content-Type: text/css");  
echo ".class3{color:red}";