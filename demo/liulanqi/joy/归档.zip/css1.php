<?php 
sleep(2);
header ("Content-Type: text/css");  
echo ".class1{color:green}";